import java.util.ArrayList;
import java.util.List;

public class Flota {
    private List<VMP> vehiculos;

    public Flota() {
        vehiculos = new ArrayList<>();
    }

    public void agregarVMP(VMP vmp) {
        vehiculos.add(vmp);
        System.out.println("VMP con ID " + vmp.getId() + " agregado a la flota");
    }

    public VMP obtenerVehiculoMasAlejado() {
        VMP masAlejado = null;
        double distanciaMaxima = Double.MIN_VALUE;
        for (VMP vmp : vehiculos) {
            double distancia = vmp.distanciaAlCentro();
            if (distancia > distanciaMaxima) {
                distanciaMaxima = distancia;
                masAlejado = vmp;
            }
        }
        return masAlejado;
    }

    public List<VMP> obtenerVehiculosAbandonados(double radio) {
        List<VMP> abandonados = new ArrayList<>();
        for (VMP vmp : vehiculos) {
            if (!vmp.isAparcado() && vmp.distanciaAlCentro() > radio) {
                abandonados.add(vmp);
                vmp.bloquear();
            }
        }
        return abandonados;
    }

    public List<VMPElectrico> obtenerVehiculosElectricosBateriaBaja(double porcentajeBateria) {
        List<VMPElectrico> electricosBateriaBaja = new ArrayList<>();
        for (VMP vmp : vehiculos) {
            if (vmp instanceof VMPElectrico) {
                VMPElectrico vehiculoElectrico = (VMPElectrico) vmp;
                if (vehiculoElectrico.getPorcentajeCarga() < porcentajeBateria) {
                    electricosBateriaBaja.add(vehiculoElectrico);
                    vehiculoElectrico.setCargando(true);
                }
            }
        }
        return electricosBateriaBaja;
    }

    public List<VMP> obtenerFlota() {
        return vehiculos;
    }

    public double calcularPorcentajeVehiculosEnUsoPatinete() {
        int totalPatinetes = 0;
        int patinetesEnUso = 0;
        for (VMP vmp : vehiculos) {
            if (vmp instanceof Patinete) {
                totalPatinetes++;
                if (!vmp.isAparcado()) {
                    patinetesEnUso++;
                }
            }
        }
        return (double) patinetesEnUso / totalPatinetes * 100;
    }
}
