// Clase Patinete
public class Patinete extends VMP {
    public Patinete(int id, double[] location) {
        super(id, location);
    }

    public Patinete(int id, double[] location, boolean aparcado, boolean disponible) {
        super(id, location, aparcado, disponible);
    }
}