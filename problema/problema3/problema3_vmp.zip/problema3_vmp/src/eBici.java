// Clase Bicicleta
public class eBici extends VMPElectrico {
    public eBici(int id, double[] location, int porcentajeCarga, boolean cargando) {
        super(id, location, porcentajeCarga, cargando);
    }

    public eBici(int id, double[] location, boolean aparcado, boolean disponible,
                 int porcentajeCarga, boolean cargando) {
        super(id, location, aparcado, disponible, porcentajeCarga, cargando);
    }
}
