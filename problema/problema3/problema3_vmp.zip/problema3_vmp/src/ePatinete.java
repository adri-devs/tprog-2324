// Clase Patinete
public class ePatinete extends VMPElectrico {
    public ePatinete(int id, double[] location, int porcentajeCarga,
                     boolean cargando) {
        super(id, location, porcentajeCarga, cargando);
    }

    public ePatinete(int id, double[] location, boolean aparcado,
                     boolean disponible, int porcentajeCarga, boolean cargando){
        super(id, location, aparcado, disponible, porcentajeCarga, cargando);
    }
}
