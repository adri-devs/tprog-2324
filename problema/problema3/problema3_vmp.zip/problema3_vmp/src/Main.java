public class Main {
    public static void main(String[] args) {
        Flota flota = new Flota();

        // Agregar VMP a la flota
        VMP bicicleta = new Bicicleta(1, new double[]{2.5, 3.0});
        VMP patinete = new Patinete(2, new double[]{-1.0, 2.0});
        VMP electricBici = new eBici(3, new double[]{0.0, 0.0}, 100, false);
        VMP electricPatinete = new ePatinete(4, new double[]{1.0, -1.0}, 100, false);
        flota.agregarVMP(bicicleta);
        flota.agregarVMP(patinete);
        flota.agregarVMP(electricBici);
        flota.agregarVMP(electricPatinete);
        /* Debugging
        System.out.println("Listado de vehiculos:");
        for (VMP vmp : flota.obtenerFlota()) {
            System.out.println(
                    "ID: " + vmp.getId() + ", Aparcado: " + vmp.isAparcado() +
                    ", Disponible: " + vmp.isDisponible() + ", Distancia al centro: " +
                    vmp.distanciaAlCentro() + " unidades" + ", Tipo: " + vmp.getClass().getSimpleName()
            + ", Cargando: " + (vmp instanceof VMPElectrico ? ((VMPElectrico) vmp).isCargando() : "N/A") +
                    ", Porcentaje de carga: " + (vmp instanceof VMPElectrico ? ((VMPElectrico) vmp).getPorcentajeCarga() : "N/A") + "%"
            + ", Ubicación: (" + vmp.getUbicacion()[0] + ", " + vmp.getUbicacion()[1] + ")");
        }
        */

        // Vehículo más alejado del centro
        System.out.println("Vehículo más alejado del centro:");
        VMP masAlejado = flota.obtenerVehiculoMasAlejado();
        System.out.println("ID: " + masAlejado.getId() + ", Distancia al centro: " + masAlejado.distanciaAlCentro() + " unidades");

        // Obtener los vehículos abandonados fuera de un radio dado
        System.out.println("\nGenerando 20 vehiculos nuevos... alguno abandonado y otros con poca bateria.");
        for (int i = 5; i < 25; i++) {
            eBici bici = new eBici(i, new double[]{i, i}, 100, true);
            if(i == 10 || i == 15 || i == 20) {
                bici.setAparcado(false);
                bici.setDisponible(true);
            } else if (i == 12 || i == 17 || i == 22) {
                bici.setAparcado(false);
                bici.setDisponible(false);
            } else if (i == 13 || i == 18 || i == 23) {
                bici.setPorcentajeCarga(i);
                bici.setCargando(false);
            }
            flota.agregarVMP(bici);
        }
        System.out.println("\nVehículos abandonados fuera de un radio de 1.2 unidades:");
        double radio = 1.2;
        for (VMP vmp : flota.obtenerVehiculosAbandonados(radio)) {
            System.out.println("ID: " + vmp.getId());
            System.out.println("Bloqueando vehículo con ID " + vmp.getId() + "...");
            vmp.bloquear();
        }

        // Obtener los vehículos eléctricos con batería baja
        System.out.println("\nVehículos eléctricos con batería baja (menor al 50%):");
        double porcentajeBateria = 50.0;
        for (VMPElectrico vehiculo : flota.obtenerVehiculosElectricosBateriaBaja(porcentajeBateria)) {
            System.out.println("ID: " + vehiculo.getId());
            System.out.println("Bloqueando vehículo con ID " + vehiculo.getId() + "...");
            vehiculo.bloquear();
        }

        // Calcular el porcentaje de vehículos en uso de tipo patinete
        System.out.println("\nPorcentaje de vehículos en uso de tipo patinete:");
        double porcentajeUsoPatinete = flota.calcularPorcentajeVehiculosEnUsoPatinete();
        System.out.println(porcentajeUsoPatinete + "% de patinetes en uso");
    }
}
