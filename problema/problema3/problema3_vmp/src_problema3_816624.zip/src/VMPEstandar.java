public class VMPEstandar extends VMP {
    public VMPEstandar(int id, double[] location) {
        super(id, location);
    }
}

