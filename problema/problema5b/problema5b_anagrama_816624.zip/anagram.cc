/*
 * Autor: Adrián Pérez Pallarés
 * NIP: 816624
 * Fecha últ. modificación: 06/03/2024
 * Descripción: Programa que lee un diccionario de palabras y un número entero cota,
 * para producir una lista de anagramas que contienen al menos cota palabras.
 */

#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>
#include <set>
#include <map>

using namespace std;

class Anagrama {
public:
    set<string> setPalabras;
    int cota;

    // Constructor
    Anagrama(const set<string>& _setPalabras, int _cota) : setPalabras(_setPalabras), cota(_cota) {}
};

// Función para comparar dos objetos de la clase Anagrama
bool esMayor(const Anagrama& a, const Anagrama& b) {
    /* if (a.cota == b.cota) {
        return a.setPalabras.size() > b.setPalabras.size();
    } */
    return a.cota > b.cota;
}

// Función que devuelve un vector de objetos de la clase Anagrama
vector<Anagrama> obtenerAnagramas(vector<string> dict, int cota) {
    // mapAnagramas asocia a cada palabra ordenada alfabéticamente
    // un conjunto de palabras
    map<string, set<string>> mapAnagrama;

    // Rellenamos mapAnagramas
    for (string palabra : dict) {
        string temp = palabra;
        sort(temp.begin(), temp.end());
        mapAnagrama[temp].insert(palabra);
    }

    // Creamos un vector de objetos de la clase Anagrama
    vector<Anagrama> vecAnagrama;
    for (auto anagrama : mapAnagrama) {
        if (anagrama.second.size() > cota) {
            vecAnagrama.emplace_back(anagrama.second, anagrama.second.size());
        }
    }

    // Ordenamos el vector de objetos de la clase Anagrama
    sort(vecAnagrama.begin(), vecAnagrama.end(), esMayor);
    return vecAnagrama;
}


int main(int argc, char* argv[]) {
    if (argc != 3) {
        cout << "Uso: ./main.exe <diccionario> <cota>" << endl;
        return -1;
    }
    string palabra;
    vector<string> dict;
    string ficheroDict = argv[1];
    int cota = stoi(argv[2]);
    ifstream fichero(ficheroDict);

    // Cargamos el archivo en el vector dict
    if (!fichero.is_open()) {
        cout << "No se pudo abrir el archivo " << ficheroDict << endl;
        return 1;
    }
    while (fichero >> palabra) {
        dict.push_back(palabra);
    }

    // Obtenemos los anagramas
    vector<Anagrama> anagramas = obtenerAnagramas(dict, cota);
    for (auto anagrama : anagramas) {
        for (auto palabra : anagrama.setPalabras) {
            cout << palabra << " ";
        }
        cout << endl;
    }
    return 0;
}