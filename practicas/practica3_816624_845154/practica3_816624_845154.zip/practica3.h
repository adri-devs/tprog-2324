#pragma once

#include "item.h"
#include "carga.h"
#include "producto.h"
#include "almacen.h"
#include "contenedor.h"
#include "camion.h"