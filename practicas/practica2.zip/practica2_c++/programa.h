#ifndef PROGRAMA_H
#define PROGRAMA_H

#include <iostream>
#include <iomanip>
#include <stack>

#include "instruccion.h"

class Programa {
    protected:
        int nInstrucciones;
        int pc;
        Instruccion** prog;
    public:
        Programa(int nInstrucciones);
        ~Programa();
        void setInstruccion(int i, Instruccion* instruccion);
        Instruccion* getInstruccion(int i) const;
        int getNInstrucciones() const;
        void listar() const;
        void ejecutar(std::stack<int>& pila);
};

class Sumador : public Programa {
    public:
        Sumador();
};

class CuentaAtras : public Programa {
    public:
        CuentaAtras();
};

class Factorial : public Programa {
    public:
        Factorial();
};

#endif // PROGRAMA_H