#include "instruccion.h"

void Add::ejecutar(std::stack<int>& pila, int& pc) {
    int a = pila.top();
    pila.pop();
    int b = pila.top();
    pila.pop();
    pila.push(a + b);
    pc++;
}

std::string Add::toString() const {
    return "add";
}

void Read::ejecutar(std::stack<int>& pila, int& pc) {
    int a;
    std::cin >> a;
    pila.push(a);
    pc++;
}

std::string Read::toString() const {
    return "read";
}

void Write::ejecutar(std::stack<int>& pila, int& pc) {
    std::cout << pila.top() << std::endl;
    pila.pop();
    pc++;
}

std::string Write::toString() const {
    return "write";
}

Push::Push(int val) : c(val) {}

void Push::ejecutar(std::stack<int>& pila, int& pc) {
    pila.push(c);
    pc++;
}

std::string Push::toString() const {
    return "push " + std::to_string(c);
}

void Dup::ejecutar(std::stack<int>& pila, int& pc) {
    int val = pila.top();
    pila.pop();
    pila.push(val);
    pila.push(val);
    pc++;
}

std::string Dup::toString() const {
    return "dup";
}

Jumpif::Jumpif(int val) : l(val) {}

void Jumpif::ejecutar(std::stack<int>& pila, int& pc) {
    int val = pila.top();
    pila.pop();
    if (val >= 0) {
        pc = l;
    }
    else {
        pc++;
    }
}

std::string Jumpif::toString() const {
    return "jumpif " + std::to_string(l);
}

void Mul::ejecutar(std::stack<int>& pila, int& pc) {
    int a = pila.top();
    pila.pop();
    int b = pila.top();
    pila.pop();
    pila.push(a * b);
    pc++;
}

std::string Mul::toString() const {
    return "mul";
}

void Swap::ejecutar(std::stack<int>& pila, int& pc) {
    int a = pila.top();
    pila.pop();
    int b = pila.top();
    pila.pop();
    pila.push(a);
    pila.push(b);
    pc++;
}

std::string Swap::toString() const {
    return "swap";
}

void Over::ejecutar(std::stack<int>& pila, int& pc) {
    int a = pila.top();
    pila.pop();
    int b = pila.top();
    pila.pop();
    pila.push(b);
    pila.push(a);
    pila.push(b);
    pc++;
}

std::string Over::toString() const {
    return "over";
}