#include "programa.h"

Programa::Programa(int nInstrucciones) : nInstrucciones(nInstrucciones) {
    prog = new Instruccion*[nInstrucciones];
    pc = 0;
}

Programa::~Programa() {
    for (int i = 0; i < getNInstrucciones(); i++) {
        delete getInstruccion(i);
    }

    delete[] prog;
}

void Programa::setInstruccion(int i, Instruccion* instruccion) {
    prog[i] = instruccion;
}

Instruccion* Programa::getInstruccion(int i) const {
    return prog[i];
}

int Programa::getNInstrucciones() const {
    return nInstrucciones;
}

void Programa::listar() const {
    std::cout << "Programa:" << std::endl;
    for (int i = 0; i < nInstrucciones; i++) {
        std::cout << std::setw(2) << std::to_string(i) << "  " << prog[i]->toString() + "\n";
    }
}

void Programa::ejecutar(std::stack<int>& pila) {
    std::cout << "Ejecucion:" << std::endl;
    while (pc < nInstrucciones) {
        prog[pc]->ejecutar(pila, pc);
    }
}

Sumador::Sumador() : Programa(4) {
    setInstruccion(0, new Read());
    setInstruccion(1, new Read());
    setInstruccion(2, new Add());
    setInstruccion(3, new Write());
}

CuentaAtras::CuentaAtras() : Programa(7) {
    setInstruccion(0, new Read());
    setInstruccion(1, new Dup());
    setInstruccion(2, new Write());
    setInstruccion(3, new Push(-1));
    setInstruccion(4, new Add());
    setInstruccion(5, new Dup());
    setInstruccion(6, new Jumpif(1));
}

Factorial::Factorial() : Programa(14) {
    setInstruccion(0, new Push(1));
    setInstruccion(1, new Read());
    setInstruccion(2, new Swap());
    setInstruccion(3, new Over());
    setInstruccion(4, new Mul());
    setInstruccion(5, new Swap());
    setInstruccion(6, new Push(-1));
    setInstruccion(7, new Add());
    setInstruccion(8, new Dup());
    setInstruccion(9, new Push(-2));
    setInstruccion(10, new Add());
    setInstruccion(11, new Jumpif(2));
    setInstruccion(12, new Swap());
    setInstruccion(13, new Write());
}