import java.util.Stack;

public interface Instruccion {
    void ejecutar(Stack<Integer> pila, int pc);
    String toString();
}