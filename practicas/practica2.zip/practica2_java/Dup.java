import java.util.Stack;

public class Dup implements Instruccion {
    public void ejecutar(Stack<Integer> pila, int pc) {
        int val = pila.peek();
        pila.push(val);
        pc++;
    }

    public String toString() {
        return "dup";
    }
}